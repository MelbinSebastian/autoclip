"""Find the best clips in a transcript.

Two modes:
  * heuristic (default, free, offline): scores every possible window of whole
    sentences on hook strength, emotion, pace, audio energy and completeness.
  * llm (optional): asks Claude to pick viral moments. Needs ANTHROPIC_API_KEY.
"""
import json
import math
import re
import subprocess

import numpy as np

HOOK_WORDS = {
    "how", "why", "what", "secret", "never", "always", "stop", "mistake", "truth", "nobody",
    "everyone", "best", "worst", "biggest", "imagine", "listen", "wait", "crazy", "insane",
    "actually", "really", "you", "your", "here's", "this", "problem", "wrong", "first",
}
EMOTION_WORDS = {
    "love", "hate", "amazing", "incredible", "shocking", "huge", "money", "million", "billion",
    "scared", "fear", "angry", "happy", "sad", "dead", "died", "kill", "win", "lost", "fail",
    "failed", "success", "rich", "broke", "unbelievable", "insane", "crazy", "best", "worst",
    "dream", "life", "changed", "important", "never", "everything", "nothing", "free", "wow",
}
FILLERS = {"um", "uh", "uhm", "erm", "hmm", "like", "basically", "literally"}

_tok = re.compile(r"[a-zA-Z']+|\d+")


# ---------------- sentences ----------------

def build_sentences(transcript, max_gap=0.8, max_words=30):
    """Merge all words into sentence units (split on . ? ! or long pauses)."""
    words = [w for s in transcript["segments"] for w in s.get("words", [])]
    sents, cur = [], []

    def flush():
        if cur:
            sents.append({"start": cur[0]["start"], "end": cur[-1]["end"],
                          "text": " ".join(w["word"] for w in cur), "words": list(cur)})
            cur.clear()

    for w in words:
        if cur and (w["start"] - cur[-1]["end"] > max_gap or len(cur) >= max_words):
            flush()
        cur.append(w)
        if w["word"].rstrip('"\')').endswith((".", "?", "!")):
            flush()
    flush()
    return sents


# ---------------- audio energy ----------------

def audio_energy(video, sr=8000, hop=0.5):
    """Loudness z-score per `hop` seconds. Streams audio so long videos stay low-memory."""
    cmd = ["ffmpeg", "-v", "error", "-i", str(video), "-vn", "-ac", "1", "-ar", str(sr), "-f", "s16le", "-"]
    try:
        proc = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.DEVNULL)
    except FileNotFoundError:
        return None
    n = int(sr * hop) * 2
    vals = []
    while True:
        buf = proc.stdout.read(n)
        if len(buf) < 4:
            break
        a = np.frombuffer(buf[: len(buf) // 2 * 2], np.int16).astype(np.float32) / 32768
        vals.append(20 * math.log10(math.sqrt(float((a ** 2).mean()) + 1e-10)))
    proc.wait()
    if not vals:
        return None
    db = np.array(vals)
    return {"hop": hop, "z": (db - db.mean()) / (db.std() + 1e-6)}


def _energy(energy, start, end):
    if energy is None:
        return 0.0
    i, j = int(start / energy["hop"]), max(int(end / energy["hop"]), int(start / energy["hop"]) + 1)
    seg = energy["z"][i:j]
    return float(np.clip(seg.mean(), -1.5, 1.5)) if len(seg) else 0.0


# ---------------- scoring ----------------

def score_window(sents, energy=None):
    first = sents[0]["text"].lower()
    text = " ".join(s["text"] for s in sents).lower()
    toks = _tok.findall(text) or ["x"]
    first_toks = _tok.findall(first)[:12]
    dur = max(sents[-1]["end"] - sents[0]["start"], 0.1)

    hook = 0.0
    if "?" in first:
        hook += 1.0
    hook += min(sum(t in HOOK_WORDS for t in first_toks), 3) * 0.4
    if any(t.isdigit() for t in first_toks):
        hook += 0.5
    if first_toks and first_toks[0] in {"and", "but", "so", "because", "or", "then"}:
        hook -= 0.8  # starts mid-thought

    emotion = min(sum(t in EMOTION_WORDS for t in toks) / len(toks) * 25, 2.0)
    emotion += min(text.count("!") * 0.3, 0.9)
    wps = len(toks) / dur
    pace = 1.0 if 2.2 <= wps <= 3.8 else max(0.0, 1 - abs(wps - 3.0) / 3)
    complete = 1.0 if sents[-1]["text"].rstrip().endswith((".", "!", "?")) else 0.0
    filler = min(sum(t in FILLERS for t in toks) / len(toks) * 15, 2.0)

    return round(2.0 * hook + emotion + _energy(energy, sents[0]["start"], sents[-1]["end"])
                 + 0.5 * pace + 0.7 * complete - filler, 3)


def heuristic_pick(sents, n, min_len, max_len, energy=None):
    cands = []
    for i in range(len(sents)):
        for j in range(i, len(sents)):
            dur = sents[j]["end"] - sents[i]["start"]
            if dur > max_len:
                break
            if dur >= min_len:
                cands.append((score_window(sents[i:j + 1], energy), i, j))
    cands.sort(reverse=True)

    chosen = []
    for sc, i, j in cands:
        s, e = sents[i]["start"], sents[j]["end"]
        if all(e + 1 < c["start"] or s > c["end"] + 1 for c in chosen):
            chosen.append({"start": s, "end": e, "score": sc,
                           "title": _title(sents[i]["text"]), "reason": "heuristic"})
        if len(chosen) >= n:
            break
    return sorted(chosen, key=lambda c: c["start"])


def _title(text, maxw=8):
    w = re.sub(r"[^\w\s'?!-]", "", text).split()
    return " ".join(w[:maxw]) + ("..." if len(w) > maxw else "")


# ---------------- LLM mode ----------------

LLM_PROMPT = """You are an expert short-form video editor (TikTok, Reels, Shorts).
Below is a timestamped transcript. Pick the {n} best self-contained clips, each {min_len}-{max_len} seconds.
A great clip: strong hook in the first 3 seconds, one complete idea, emotional or surprising payoff,
makes sense without the rest of the video. Clips must not overlap.

Return ONLY a JSON array, no prose, no markdown fences:
[{{"start": <seconds>, "end": <seconds>, "title": "<catchy title, max 8 words>", "reason": "<why it works>", "score": <1-10>}}]

TRANSCRIPT:
{transcript}"""


def llm_pick(sents, n, min_len, max_len, model):
    import anthropic  # optional dependency

    lines = "\n".join(f"[{s['start']:.1f}-{s['end']:.1f}] {s['text']}" for s in sents)
    msg = anthropic.Anthropic().messages.create(
        model=model, max_tokens=4000,
        messages=[{"role": "user", "content": LLM_PROMPT.format(n=n, min_len=min_len, max_len=max_len, transcript=lines)}],
    )
    raw = "".join(b.text for b in msg.content if b.type == "text")
    raw = re.sub(r"```(?:json)?", "", raw).strip()
    picks = json.loads(raw[raw.find("["): raw.rfind("]") + 1])

    out = []
    for p in picks[:n]:  # snap to real sentence boundaries
        s = min(sents, key=lambda x: abs(x["start"] - float(p["start"])))["start"]
        e = min(sents, key=lambda x: abs(x["end"] - float(p["end"])))["end"]
        if e - s >= 3:
            out.append({"start": s, "end": e, "score": p.get("score", 0),
                        "title": p.get("title", "clip"), "reason": p.get("reason", "llm")})
    return sorted(out, key=lambda c: c["start"])


# ---------------- entry ----------------

def find_clips(transcript, video=None, n=0, min_len=20, max_len=60, use_llm=False,
               llm_model="claude-sonnet-5-5", pad=(0.15, 0.35), duration=None):
    sents = build_sentences(transcript)
    if not sents:
        raise SystemExit("Transcript is empty - no speech found.")
    total = duration or sents[-1]["end"]
    if n <= 0:  # auto: ~1 clip per 3 min, 1..10
        n = max(1, min(10, round(total / 180)))
    if total < min_len:
        min_len = max(3, total * 0.5)

    clips = []
    if use_llm:
        try:
            print(f"[analyze] asking {llm_model} for best moments...")
            clips = llm_pick(sents, n, min_len, max_len, llm_model)
        except Exception as e:  # noqa: BLE001
            print(f"[analyze] LLM failed ({e}); falling back to heuristic")
    if not clips:
        energy = audio_energy(video) if video else None
        clips = heuristic_pick(sents, n, min_len, max_len, energy)

    for c in clips:
        c["start"] = round(max(0.0, c["start"] - pad[0]), 2)
        c["end"] = round(min(total, c["end"] + pad[1]), 2)
    return clips
