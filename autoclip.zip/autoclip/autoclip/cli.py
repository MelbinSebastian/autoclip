"""autoclip VIDEO [options]  ->  short, subtitled, vertical clips."""
import argparse
import json
import sys
import time
from pathlib import Path

from . import __version__
from .analyze import find_clips
from .render import ASPECTS, output_size, render_clip
from .subtitles import STYLES, build_ass, clip_words
from .transcribe import load_transcript, transcribe
from .utils import check_ffmpeg, fmt_time, probe, slugify


def parse_args(argv=None):
    p = argparse.ArgumentParser(prog="autoclip", description="Turn long videos into short subtitled clips.")
    p.add_argument("video", nargs="?", help="input video file (any length)")
    p.add_argument("-o", "--output", help="output folder (default: clips/<video name>)")
    p.add_argument("-n", "--clips", type=int, default=0, help="number of clips (0 = auto, ~1 per 3 min)")
    p.add_argument("--min", dest="min_len", type=float, default=20, help="min clip seconds (default 20)")
    p.add_argument("--max", dest="max_len", type=float, default=60, help="max clip seconds (default 60)")
    p.add_argument("-s", "--style", default="karaoke",
                   help=f"subtitle style: {', '.join(STYLES)}, none, all (default karaoke)")
    p.add_argument("-a", "--aspect", default="9:16", choices=[*ASPECTS, "original"])
    p.add_argument("--font", default="Arial", help="font name installed on system (default Arial)")
    p.add_argument("--fonts-dir", help="folder with .ttf/.otf fonts to use")
    p.add_argument("--transcript", help="use existing transcript (.json/.srt/.vtt), skip whisper")
    p.add_argument("--model", default="small", help="whisper size: tiny, base, small, medium, large-v3")
    p.add_argument("--language", help="force language code (en, hi, es...). default auto-detect")
    p.add_argument("--device", default="auto", choices=["auto", "cpu", "cuda"])
    p.add_argument("--llm", action="store_true", help="use Claude to pick clips (needs ANTHROPIC_API_KEY)")
    p.add_argument("--llm-model", default="claude-sonnet-5-5")
    p.add_argument("--no-face", action="store_true", help="center crop instead of face tracking")
    p.add_argument("--crf", type=int, default=20, help="video quality, lower = better (default 20)")
    p.add_argument("--analyze-only", action="store_true", help="only print/save chosen clips, no render")
    p.add_argument("--list-styles", action="store_true", help="show subtitle styles and exit")
    p.add_argument("--version", action="version", version=f"autoclip {__version__}")
    return p.parse_args(argv)


def main(argv=None):
    args = parse_args(argv)
    if args.list_styles:
        for k, v in STYLES.items():
            print(f"  {k:<9} {v['desc']}")
        return 0
    if not args.video:
        print("error: give a video file. Try: autoclip my_video.mp4", file=sys.stderr)
        return 2

    styles = list(STYLES) if args.style == "all" else ([] if args.style == "none" else [args.style])
    for s in styles:
        if s not in STYLES:
            print(f"error: unknown style '{s}'. Use --list-styles", file=sys.stderr)
            return 2

    check_ffmpeg()
    video = Path(args.video)
    if not video.exists():
        print(f"error: file not found: {video}", file=sys.stderr)
        return 2
    out_dir = Path(args.output or Path("clips") / slugify(video.stem))
    out_dir.mkdir(parents=True, exist_ok=True)
    t0 = time.time()

    info = probe(video)
    print(f"[probe] {info['width']}x{info['height']} @ {info['fps']:.2f}fps, {fmt_time(info['duration'])}")

    # 1. transcript (cached so re-runs with other styles are instant)
    cache = out_dir / "transcript.json"
    if args.transcript:
        transcript = load_transcript(args.transcript)
    elif cache.exists():
        print(f"[transcribe] using cached {cache}")
        transcript = json.loads(cache.read_text(encoding="utf-8"))
    else:
        transcript = transcribe(video, args.model, args.language, args.device)
    cache.write_text(json.dumps(transcript, ensure_ascii=False, indent=1), encoding="utf-8")

    # 2. pick clips
    clips = find_clips(transcript, video if info["has_audio"] else None, args.clips,
                       args.min_len, args.max_len, args.llm, args.llm_model, duration=info["duration"])
    print(f"[analyze] {len(clips)} clips selected")
    for i, c in enumerate(clips, 1):
        print(f"  #{i}  {fmt_time(c['start'])} -> {fmt_time(c['end'])}  "
              f"({c['end'] - c['start']:.0f}s)  score {c['score']}  \"{c['title']}\"")

    # 3. render
    if not args.analyze_only:
        out_w, out_h = output_size(args.aspect, info["width"], info["height"])
        for i, c in enumerate(clips, 1):
            words = clip_words(transcript, c["start"], c["end"])
            c["files"] = []
            for style in (styles or [None]):
                ass = build_ass(words, style, out_w, out_h, args.font) if style else None
                name = f"{i:02d}_{slugify(c['title'])}" + (f"_{style}" if len(styles) > 1 else "") + ".mp4"
                print(f"[render] {name}")
                render_clip(video, info, c["start"], c["end"], out_dir / name, args.aspect, ass,
                            face=not args.no_face, crf=args.crf, fonts_dir=args.fonts_dir)
                c["files"].append(name)

    (out_dir / "clips.json").write_text(json.dumps(clips, ensure_ascii=False, indent=2), encoding="utf-8")
    print(f"[done] {len(clips)} clips -> {out_dir}  ({time.time() - t0:.0f}s)")
    return 0


if __name__ == "__main__":
    sys.exit(main())
