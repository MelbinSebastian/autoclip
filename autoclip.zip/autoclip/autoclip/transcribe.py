"""Speech-to-text with word timestamps. Also loads existing .json / .srt / .vtt transcripts."""
import json
import re
from pathlib import Path


def transcribe(video, model_size="small", language=None, device="auto"):
    try:
        from faster_whisper import WhisperModel
    except ImportError:
        raise SystemExit("faster-whisper not installed. Run: pip install faster-whisper")

    print(f"[transcribe] loading whisper '{model_size}' ({device})...")
    model = WhisperModel(model_size, device=device, compute_type="default")
    segments, info = model.transcribe(str(video), word_timestamps=True, vad_filter=True, language=language)
    print(f"[transcribe] language: {info.language} ({info.language_probability:.0%})")

    out = []
    for seg in segments:
        words = [
            {"word": w.word.strip(), "start": round(w.start, 3), "end": round(w.end, 3)}
            for w in (seg.words or []) if w.word.strip()
        ]
        if words:
            out.append({"start": round(seg.start, 3), "end": round(seg.end, 3),
                        "text": seg.text.strip(), "words": words})
            print(f"  [{seg.start:7.1f}s] {seg.text.strip()[:70]}")
    return {"language": info.language, "segments": out}


# ---------- loading existing transcripts ----------

_TS = re.compile(r"(?:(\d+):)?(\d{1,2}):(\d{2})[,.](\d{1,3})")


def _ts(s):
    m = _TS.search(s)
    if not m:
        raise ValueError(f"bad timestamp: {s}")
    h, mi, se, ms = m.groups()
    return int(h or 0) * 3600 + int(mi) * 60 + int(se) + int(ms.ljust(3, "0")) / 1000


def _cue_words(text, start, end):
    """SRT/VTT have no word timings -> spread words across the cue, weighted by length."""
    toks = text.split()
    if not toks:
        return []
    weights = [len(t) + 1 for t in toks]
    total, t, words = sum(weights), start, []
    for tok, wt in zip(toks, weights):
        d = (end - start) * wt / total
        words.append({"word": tok, "start": round(t, 3), "end": round(t + d, 3)})
        t += d
    return words


def _parse_subs(text):
    segs = []
    for block in re.split(r"\n\s*\n", text.replace("\r", "")):
        lines = [l for l in block.strip().split("\n") if l.strip()]
        idx = next((i for i, l in enumerate(lines) if "-->" in l), None)
        if idx is None:
            continue
        a, b = lines[idx].split("-->")
        start, end = _ts(a), _ts(b)
        body = re.sub(r"<[^>]+>|\{[^}]+\}", "", " ".join(lines[idx + 1:])).strip()
        if body and end > start:
            segs.append({"start": start, "end": end, "text": body, "words": _cue_words(body, start, end)})
    return segs


def load_transcript(path):
    path = Path(path)
    raw = path.read_text(encoding="utf-8", errors="ignore")
    if path.suffix.lower() == ".json":
        data = json.loads(raw)
        if isinstance(data, list):
            data = {"segments": data}
        for s in data["segments"]:
            if not s.get("words"):
                s["words"] = _cue_words(s["text"], s["start"], s["end"])
        return data
    if path.suffix.lower() in (".srt", ".vtt"):
        return {"language": None, "segments": _parse_subs(raw)}
    raise SystemExit(f"Unsupported transcript format: {path.suffix} (use .json, .srt or .vtt)")
