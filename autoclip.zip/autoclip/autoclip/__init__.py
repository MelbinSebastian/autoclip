"""AutoClip - turn long videos into short, subtitled clips."""
__version__ = "0.1.0"
