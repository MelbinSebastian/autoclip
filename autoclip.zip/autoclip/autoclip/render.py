"""Cut + reframe + burn subtitles.

Reframe modes:
  * face tracking (OpenCV): crop window follows the biggest face, smoothed.
  * center crop (FFmpeg only): fast fallback, used with --no-face or when OpenCV missing.
"""
import os
import shutil
import subprocess
import tempfile
from pathlib import Path

from .utils import run

ASPECTS = {"9:16": (1080, 1920), "1:1": (1080, 1080), "4:5": (1080, 1350), "16:9": (1920, 1080)}


def output_size(aspect, src_w, src_h):
    if aspect == "original":
        return src_w // 2 * 2, src_h // 2 * 2
    return ASPECTS[aspect]


def _crop_box(src_w, src_h, out_w, out_h):
    r = out_w / out_h
    if src_w / src_h > r:  # source wider -> crop sides
        cw = int(src_h * r) // 2 * 2
        return cw, src_h, True
    ch = int(src_w / r) // 2 * 2
    return src_w, ch, False


def _encode_args(crf, has_audio):
    a = ["-c:v", "libx264", "-preset", "veryfast", "-crf", str(crf), "-pix_fmt", "yuv420p",
         "-movflags", "+faststart"]
    return a + (["-c:a", "aac", "-b:a", "160k"] if has_audio else ["-an"])


def render_clip(src, info, start, end, out_path, aspect="9:16", ass_text=None,
                face=True, crf=20, fonts_dir=None):
    src, out_path = str(Path(src).resolve()), str(Path(out_path).resolve())
    dur = end - start
    out_w, out_h = output_size(aspect, info["width"], info["height"])
    cw, ch, crop_sides = _crop_box(info["width"], info["height"], out_w, out_h)

    with tempfile.TemporaryDirectory() as tmp:
        sub_filter = None
        if ass_text:
            Path(tmp, "subs.ass").write_text(ass_text, encoding="utf-8")
            sub_filter = "ass=subs.ass"
            if fonts_dir:
                fd = os.path.join(tmp, "fonts")
                shutil.copytree(fonts_dir, fd)
                sub_filter += ":fontsdir=fonts"

        use_face = face and crop_sides and aspect != "original"
        if use_face:
            try:
                import cv2  # noqa: F401
            except ImportError:
                print("  [render] opencv not installed -> center crop")
                use_face = False

        if use_face:
            _render_face(src, info, start, dur, cw, ch, out_w, out_h, sub_filter, out_path, crf, tmp)
        else:
            x = (info["width"] - cw) // 2
            y = (info["height"] - ch) // 2
            vf = f"crop={cw}:{ch}:{x}:{y},scale={out_w}:{out_h}:flags=lanczos,setsar=1"
            if sub_filter:
                vf += "," + sub_filter
            cmd = ["ffmpeg", "-y", "-v", "error", "-ss", f"{start:.3f}", "-t", f"{dur:.3f}", "-i", src,
                   "-vf", vf, *_encode_args(crf, info["has_audio"]), out_path]
            run(cmd, cwd=tmp)
    return out_path


def _render_face(src, info, start, dur, cw, ch, out_w, out_h, sub_filter, out_path, crf, tmp):
    import cv2

    cascade = cv2.CascadeClassifier(cv2.data.haarcascades + "haarcascade_frontalface_default.xml")
    cap = cv2.VideoCapture(src)
    cap.set(cv2.CAP_PROP_POS_MSEC, start * 1000)
    fps = info["fps"]
    n_frames = int(round(dur * fps))
    W = info["width"]
    half = cw / 2
    cx = target = W / 2
    det_scale = 480 / W if W > 480 else 1.0

    cmd = ["ffmpeg", "-y", "-v", "error",
           "-f", "rawvideo", "-pix_fmt", "bgr24", "-s", f"{out_w}x{out_h}", "-r", f"{fps:.5f}", "-i", "-",
           "-ss", f"{start:.3f}", "-t", f"{dur:.3f}", "-i", src,
           "-map", "0:v:0", "-map", "1:a:0?", "-vf", sub_filter or "null",
           *_encode_args(crf, info["has_audio"]), "-shortest", out_path]
    proc = subprocess.Popen(cmd, cwd=tmp, stdin=subprocess.PIPE, stderr=subprocess.PIPE)

    every = max(1, int(fps / 6))  # detect ~6x per second
    last = None
    try:
        for i in range(n_frames):
            ok, frame = cap.read()
            if not ok:
                if last is None:
                    break
                frame = last
            last = frame
            if frame.shape[1] != W:  # rotated sources
                frame = cv2.resize(frame, (W, info["height"]))
            if i % every == 0:
                small = cv2.resize(frame, None, fx=det_scale, fy=det_scale) if det_scale < 1 else frame
                gray = cv2.cvtColor(small, cv2.COLOR_BGR2GRAY)
                faces = cascade.detectMultiScale(gray, 1.1, 5, minSize=(int(30 * det_scale + 10),) * 2)
                if len(faces):
                    x, y, w, h = max(faces, key=lambda f: f[2] * f[3])
                    fx = (x + w / 2) / det_scale
                    if abs(fx - target) > cw * 0.08:  # dead zone: ignore tiny moves
                        target = fx
            cx += (target - cx) * 0.12  # smooth camera move
            x0 = int(min(max(cx - half, 0), W - cw))
            crop = frame[:ch, x0:x0 + cw]
            proc.stdin.write(cv2.resize(crop, (out_w, out_h), interpolation=cv2.INTER_LANCZOS4).tobytes())
    except BrokenPipeError:
        pass
    finally:
        cap.release()
        if proc.stdin:
            try:
                proc.stdin.close()
            except BrokenPipeError:
                pass
        err = proc.stderr.read().decode(errors="ignore")
        proc.wait()
    if proc.returncode != 0:
        raise RuntimeError(f"ffmpeg failed:\n{err[-2000:]}")
