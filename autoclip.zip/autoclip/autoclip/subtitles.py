"""Animated subtitles as ASS files (burned in by FFmpeg/libass).

Add a new style: copy one entry in STYLES, change values. That's it.
Colors are ASS format &HBBGGRR (blue-green-red, NOT rgb).
"""
from .utils import fmt_time

WHITE, BLACK = "&HFFFFFF", "&H000000"
YELLOW, GREEN, CYAN, PINK = "&H00FFFF", "&H00FF7F", "&HFFFF00", "&HB469FF"

STYLES = {
    # word-by-word highlight, 3 words on screen
    "karaoke": dict(desc="3 words, active word turns yellow", mode="highlight", words=3,
                    size=0.075, color=WHITE, active=YELLOW, outline=4, shadow=2,
                    upper=False, box=False, pos=0.28, font_bold=True),
    # one big word at a time with a pop-in bounce
    "pop": dict(desc="one big word at a time, bounce animation", mode="single", words=1,
                size=0.11, color=WHITE, active=WHITE, outline=6, shadow=3,
                upper=True, box=False, pos=0.30, font_bold=True),
    # creator style: caps, thick outline, active word green and bigger
    "bold": dict(desc="ALL CAPS, 2 words, active word green + scaled", mode="highlight", words=2,
                 size=0.09, color=WHITE, active=GREEN, outline=7, shadow=4,
                 upper=True, box=False, pos=0.30, font_bold=True, scale_active=True),
    # clean sentence captions, low on screen
    "minimal": dict(desc="clean sentence captions, small, bottom", mode="static", words=7,
                    size=0.05, color=WHITE, active=WHITE, outline=1.5, shadow=2,
                    upper=False, box=False, pos=0.10, font_bold=False),
    # boxed captions with background, active word cyan
    "boxed": dict(desc="dark box behind text, active word cyan", mode="highlight", words=4,
                  size=0.06, color=WHITE, active=CYAN, outline=10, shadow=0,
                  upper=False, box=True, pos=0.22, font_bold=True),
    # neon glow
    "neon": dict(desc="pink glow, 3 words, active word white", mode="highlight", words=3,
                 size=0.075, color=PINK, active=WHITE, outline=3, shadow=0,
                 upper=True, box=False, pos=0.28, font_bold=True, glow=PINK),
}


def _esc(t):
    return t.replace("\\", "").replace("{", "(").replace("}", ")")


def _groups(words, size, max_gap=0.6):
    groups, cur = [], []
    for w in words:
        if cur and (len(cur) >= size or w["start"] - cur[-1]["end"] > max_gap
                    or cur[-1]["word"].endswith((".", "?", "!"))):
            groups.append(cur)
            cur = []
        cur.append(w)
    if cur:
        groups.append(cur)
    return groups


def clip_words(transcript, start, end):
    """Words inside [start, end], re-timed so the clip starts at 0."""
    out = []
    for seg in transcript["segments"]:
        for w in seg.get("words", []):
            if w["end"] > start and w["start"] < end:
                out.append({"word": w["word"],
                            "start": max(0.0, w["start"] - start),
                            "end": min(end - start, w["end"] - start)})
    return out


def build_ass(words, style_name, width, height, font="Arial"):
    st = STYLES[style_name]
    base = min(width, height)
    fs = int(base * st["size"])
    margin_v = int(height * st["pos"])
    border_style = 3 if st["box"] else 1
    back = "&H80000000" if st["box"] else "&H64000000"
    outline_col = "&H00141414" if st["box"] else BLACK
    bold = -1 if st["font_bold"] else 0

    header = f"""[Script Info]
ScriptType: v4.00+
PlayResX: {width}
PlayResY: {height}
WrapStyle: 0
ScaledBorderAndShadow: yes

[V4+ Styles]
Format: Name, Fontname, Fontsize, PrimaryColour, SecondaryColour, OutlineColour, BackColour, Bold, Italic, Underline, StrikeOut, ScaleX, ScaleY, Spacing, Angle, BorderStyle, Outline, Shadow, Alignment, MarginL, MarginR, MarginV, Encoding
Style: Main,{font},{fs},{st['color']},{st['active']},{outline_col},{back},{bold},0,0,0,100,100,0,0,{border_style},{st['outline']},{st['shadow']},2,{int(width*0.08)},{int(width*0.08)},{margin_v},1

[Events]
Format: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, Effect, Text
"""
    glow = f"{{\\3c{st['glow']}\\blur6}}" if st.get("glow") else ""
    lines = []

    def word_text(w):
        t = _esc(w["word"])
        return t.upper() if st["upper"] else t

    def add(s, e, text):
        if e - s > 0.01:
            lines.append(f"Dialogue: 0,{fmt_time(s)},{fmt_time(e)},Main,,0,0,0,,{glow}{text}")

    groups = _groups(words, st["words"])
    for gi, g in enumerate(groups):
        nxt = groups[gi + 1][0]["start"] if gi + 1 < len(groups) else g[-1]["end"] + 0.4
        g_end = nxt if nxt - g[-1]["end"] < 0.35 else g[-1]["end"] + 0.15  # bridge tiny gaps

        if st["mode"] == "static":
            add(g[0]["start"], g_end, " ".join(word_text(w) for w in g))
        elif st["mode"] == "single":
            w = g[0]
            pop = "{\\fscx70\\fscy70\\t(0,90,\\fscx112\\fscy112)\\t(90,160,\\fscx100\\fscy100)}"
            add(w["start"], g_end, pop + word_text(w))
        else:  # highlight
            for wi, w in enumerate(g):
                s = w["start"] if wi else g[0]["start"]
                e = g[wi + 1]["start"] if wi + 1 < len(g) else g_end
                parts = []
                for k, x in enumerate(g):
                    if k == wi:
                        sc = "\\fscx112\\fscy112" if st.get("scale_active") else ""
                        parts.append(f"{{\\1c{st['active']}&{sc}}}{word_text(x)}{{\\1c{st['color']}&\\fscx100\\fscy100}}")
                    else:
                        parts.append(word_text(x))
                add(s, e, " ".join(parts))
    return header + "\n".join(lines) + "\n"
