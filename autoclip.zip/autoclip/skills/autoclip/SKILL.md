---
name: autoclip
description: Turn a long video into short vertical clips with animated subtitles using the autoclip CLI. Use when the user asks to clip, cut, or make shorts/reels/TikToks from a video, or to add styled subtitles to clips.
---

# AutoClip skill

Tool: `autoclip` CLI from this repo. Needs ffmpeg + `pip install -e .`.

## Steps
1. Check: `ffmpeg -version` and `autoclip --version`. Install if missing.
2. Preview picks first: `autoclip VIDEO --analyze-only`. Show user the list (times, titles).
3. Ask user only if unclear: clip count, length, style. Defaults are fine: auto count, 20–60 s, karaoke, 9:16.
4. Render: `autoclip VIDEO -n N --min A --max B -s STYLE`.
5. Report output folder and `clips.json`.

## Choosing options
- Screen recording / no face → `--no-face`
- Non-English → `--language CODE`
- Existing subtitles → `--transcript file.srt` (skips whisper)
- Want smarter picks + ANTHROPIC_API_KEY set → `--llm`
- User unsure on style → `-s all`, let them compare
- Styles: karaoke, pop, bold, minimal, boxed, neon, none

## Re-runs
Transcript cached in output folder. Changing style or clip count is fast; do not delete `transcript.json`.
