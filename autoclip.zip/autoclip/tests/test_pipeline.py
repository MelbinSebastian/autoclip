import json
import shutil
import subprocess

import pytest

from autoclip.analyze import build_sentences, find_clips
from autoclip.subtitles import STYLES, build_ass, clip_words
from autoclip.transcribe import _parse_subs

SRT = """1
00:00:00,000 --> 00:00:04,000
Why do most people never get rich?

2
00:00:04,500 --> 00:00:09,000
Here's the secret nobody tells you about money.

3
00:00:09,500 --> 00:00:14,000
um so basically uh like we went to the store.

4
00:00:14,500 --> 00:00:20,000
The biggest mistake is waiting. Start today and it changes your life!
"""


def transcript():
    return {"segments": _parse_subs(SRT)}


def test_parse_srt():
    segs = transcript()["segments"]
    assert len(segs) == 4
    assert segs[0]["words"][0]["word"] == "Why"
    assert segs[3]["end"] == 20.0


def test_sentences():
    s = build_sentences(transcript())
    assert s[0]["text"].endswith("rich?")


def test_find_clips_prefers_hook():
    clips = find_clips(transcript(), n=1, min_len=4, max_len=10)
    assert clips[0]["start"] < 1  # hook question wins over filler


@pytest.mark.parametrize("style", list(STYLES))
def test_ass_styles(style):
    words = clip_words(transcript(), 0, 10)
    ass = build_ass(words, style, 1080, 1920)
    assert "[Events]" in ass and ass.count("Dialogue:") >= 2


@pytest.mark.skipif(not shutil.which("ffmpeg"), reason="ffmpeg missing")
def test_end_to_end(tmp_path):
    vid = tmp_path / "in.mp4"
    subprocess.run(["ffmpeg", "-y", "-v", "error", "-f", "lavfi", "-i", "testsrc2=s=1280x720:d=20",
                    "-f", "lavfi", "-i", "sine=f=300:d=20", "-shortest", str(vid)], check=True)
    srt = tmp_path / "t.srt"
    srt.write_text(SRT)
    from autoclip.cli import main
    out = tmp_path / "out"
    assert main([str(vid), "--transcript", str(srt), "-n", "1", "--min", "5", "--max", "10",
                 "-o", str(out)]) == 0
    clips = json.loads((out / "clips.json").read_text())
    assert (out / clips[0]["files"][0]).stat().st_size > 1000
