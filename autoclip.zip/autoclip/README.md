# AutoClip ✂️

Turn any long video (podcast, stream, interview, lecture) into short, vertical, subtitled clips for TikTok, Reels and Shorts. One command. Free. Runs on your computer.

![subtitle styles](docs/styles.png)
*Styles left → right: karaoke, pop, bold, minimal, boxed, neon*

## How it works

```
video ──► 1. transcribe ──► 2. find best moments ──► 3. reframe 9:16 ──► 4. burn subtitles ──► clips/
          (whisper, word      (hook, emotion, pace,     (follows the face)     (animated, 6 styles)
           timestamps)         loudness, full sentences)
```

## Install

You need **Python 3.9+** and **FFmpeg**.

```bash
# FFmpeg
#   Windows: winget install ffmpeg      Mac: brew install ffmpeg      Linux: sudo apt install ffmpeg

git clone https://github.com/YOUR_NAME/autoclip.git
cd autoclip
pip install -e .
```

## Use

```bash
autoclip my_video.mp4
```

Clips land in `clips/my_video/` with a `clips.json` report (times, titles, scores).

### Common options

| What you want | Command |
|---|---|
| 5 clips, 30–60 s | `autoclip video.mp4 -n 5 --min 30 --max 60` |
| Pick subtitle style | `autoclip video.mp4 -s bold` |
| Every style (to compare) | `autoclip video.mp4 -s all` |
| No subtitles | `autoclip video.mp4 -s none` |
| Square / keep original | `autoclip video.mp4 -a 1:1` · `-a original` |
| Non-English | `autoclip video.mp4 --language hi` |
| Better accuracy (slower) | `autoclip video.mp4 --model medium` |
| GPU | `autoclip video.mp4 --device cuda` |
| Already have subtitles | `autoclip video.mp4 --transcript subs.srt` |
| Custom font | `autoclip video.mp4 --font "Montserrat" --fonts-dir ./fonts` |
| AI picks clips (Claude) | `pip install -e ".[llm]"` then `ANTHROPIC_API_KEY=... autoclip video.mp4 --llm` |
| Preview picks, no render | `autoclip video.mp4 --analyze-only` |

See all: `autoclip --help` · styles: `autoclip --list-styles`

Transcript is cached in the output folder, so re-running with a new style skips transcription.

## Subtitle styles

| Style | Look |
|---|---|
| `karaoke` | 3 words, active word yellow (default) |
| `pop` | one big word at a time, bounce |
| `bold` | ALL CAPS, 2 words, active word green + bigger |
| `minimal` | clean sentence captions at bottom |
| `boxed` | dark box, active word cyan |
| `neon` | pink glow, caps |

Add your own: copy an entry in `autoclip/subtitles.py` → `STYLES`, change colors/size. Done.

## How clips are chosen

Default mode is offline and free. Every window of whole sentences between `--min` and `--max` seconds is scored on:

- **Hook**: first sentence has a question, number, or hook words ("secret", "never", "why"...). Starting mid-thought ("and", "but") loses points.
- **Emotion**: strong words and exclamations.
- **Energy**: louder than average audio = exciting moment.
- **Pace**: 2–4 words per second.
- **Complete**: ends on a full sentence.
- **Fillers**: "um", "uh", "like" lose points.

Top non-overlapping windows win. With `--llm`, Claude reads the whole transcript and picks instead (falls back to heuristic on error).

## Docker (no Python setup)

```bash
docker build -t autoclip .
docker run --rm -v "$PWD:/work" autoclip my_video.mp4
```

## Project layout

```
autoclip/
  cli.py         command line, runs the pipeline
  transcribe.py  whisper + .srt/.vtt/.json loader
  analyze.py     clip scoring (heuristic + Claude)
  subtitles.py   subtitle styles -> .ass
  render.py      cut, face-tracked crop, burn subs
skills/autoclip/SKILL.md   lets Claude Code run this tool for you
tests/           pytest
```

## Tips

- First run downloads the whisper model (~500 MB for `small`).
- Long videos (2–3 h) work; CPU transcription takes roughly 0.3–1× video length with `small`.
- Face tracking works best with one main speaker. Use `--no-face` for screen recordings.
- Only clip videos you own or have rights to.

## Contributing

PRs welcome: new styles, better scoring, speaker diarization, B-roll. Run `pytest` before opening.

## License

MIT
